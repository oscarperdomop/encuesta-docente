from pydantic import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str
    APP_NAME: str = 'Encuesta Docente API'
    class Config:
        env_file = '.env'

settings = Settings()
