# Encuesta Docente — Starter Pack

Este paquete incluye:
- **Postgres** por Docker (`docker-compose.yml`).
- **API (FastAPI)** con **Alembic** y dos migraciones (`users/roles` + esquema base).
- Scripts para **importar CSV** (usuarios, docentes, periodos, encuestas, asignaciones, preguntas, pesos).

## Requisitos
- Docker / Docker Compose
- Python 3.11+ (para correr la API localmente)
- (Opcional) `psql`

## Pasos rápidos
1. Levanta Postgres:
   ```bash
   docker compose up -d db
   ```
2. Configura la API:
   ```bash
   cd api
   python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   cp .env.example .env
   ```
3. Ejecuta migraciones:
   ```bash
   alembic upgrade head
   ```
4. (Opcional) Importa datos CSV (desde `../data`):
   ```bash
   python scripts/import_csv.py
   ```
5. Arranca la API:
   ```bash
   uvicorn app.main:app --reload
   # prueba: http://localhost:8000/health
   ```

## Estructura
```
encuesta-docente-starter/
├─ docker-compose.yml
├─ README.md
├─ data/                  # CSV de ejemplo/listos para importar
└─ api/
   ├─ .env.example
   ├─ requirements.txt
   ├─ alembic.ini
   ├─ alembic/
   │  ├─ env.py
   │  └─ versions/
   │     ├─ 0001_init_core.py
   │     └─ 0002_schema_core.py
   └─ app/
      ├─ main.py
      ├─ core/config.py
      ├─ db/session.py
      └─ models/__init__.py
```
